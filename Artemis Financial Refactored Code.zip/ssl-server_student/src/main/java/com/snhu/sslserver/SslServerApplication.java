/* Charles Campbell
 * 7-1 Project
 * Feb. 21, 2025
 */

package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

@RestController

class ServerController {
	//FIXME:  Add hash function to return the checksum value for the data string that should contain your name.    
	public static String calculateHash(String name) throws NoSuchAlgorithmException {  
        // Takes the instance of a string to be converted via Secure Hash Algorithm (SHA) - 256 bit (32 byte)
		MessageDigest input = MessageDigest.getInstance("SHA-256");
		// Calculate and store hash byte of input message
        byte[] hash =  input.digest(name.getBytes(StandardCharsets.UTF_8));
        // Convert the hash to an integer
        BigInteger number = new BigInteger(1, hash);
        // Convert number to into hex values
        StringBuilder hexString = new StringBuilder(number.toString(16));
        // Pad the converted hash with 0's 
        while (hexString.length() < 64) {  
            hexString.insert(0, '0');
        }
        return hexString.toString();
    }
	
	@RequestMapping("/hash")
	public String myHash() throws NoSuchAlgorithmException {
	// Input
	String data = "Hello Charles Campbell - CS Major at SNHU!";
	// Converter
	String checkSum = calculateHash(data);
	// Output hash results
	return "<p>User data: " + data + "<p>Checksum conversion via SHA-256 " + " : " + checkSum;

	}
}